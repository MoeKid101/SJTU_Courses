#include <stdio.h>

int main(int argc, char const *argv[]) {
    printf("Hello ChCore!\n");
    return 0;
}